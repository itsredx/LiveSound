import 'package:flutter/material.dart';
import 'package:audioplayers/audio_cache.dart';

void main() => runApp(LiveSoundApp());

class LiveSoundApp extends StatelessWidget {
  void playSound(String soundName) {
    final player = AudioCache();
    player.play(soundName);
  }

  Expanded buildKey(
      {String img1, String img2, String soundName1, String soundName2}) {
    return Expanded(
      child: Row(
        children: <Widget>[
          GestureDetector(
            onTap: () {
              playSound(soundName1);
            },
            child: Container(
              margin: EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: Color(0xFF1D1E33),
              ),
              child: Image(
                image: AssetImage(img1),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              playSound(soundName2);
            },
            child: Container(
              margin: EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: Color(0xFF1D1E33),
              ),
              child: Image(
                image: AssetImage(img2),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color(0xFF0A0E21),
        appBar: AppBar(
          title: Text('LIVE SOUND'),
          backgroundColor: Color(0xFF0A0E21),
        ),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: buildKey(
                  img1: 'assets/images/cat.png',
                  img2: 'assets/images/dog.png',
                  soundName1: 'sound/cat.wav',
                  soundName2: 'sound/dog.wav',
                ),
              ),
              Expanded(
                child: buildKey(
                  img1: 'assets/images/cow.png',
                  img2: 'assets/images/inset.png',
                  soundName1: 'sound/cow.wav',
                  soundName2: 'sound/insect.wav',
                ),
              ),
              Expanded(
                child: buildKey(
                  img1: 'assets/images/chicken.png',
                  img2: 'assets/images/birds.png',
                  soundName1: 'sound/chicken.wav',
                  soundName2: 'sound/birds.wav',
                ),
              ),
              Expanded(
                child: buildKey(
                  img1: 'assets/images/horse.png',
                  img2: 'assets/images/lion.png',
                  soundName1: 'sound/horse.wav',
                  soundName2: 'sound/lion.wav',
                ),
              ),
              Expanded(
                child: buildKey(
                  img1: 'assets/images/monkey.png',
                  img2: 'assets/images/wolf.png',
                  soundName1: 'sound/monkey.wav',
                  soundName2: 'sound/wolf.wav',
                ),
              ),
              Expanded(
                child: buildKey(
                  img1: 'assets/images/pig.png',
                  img2: 'assets/images/wolf.png',
                  soundName1: 'sound/pig.wav',
                  soundName2: 'sound/wolf.wav',
                ),
              ),
              /* Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    height: 50,
                    width: 170,
                    margin: EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      color: Color(0xFF1D1E33),
                    ),
                    child: IconButton(
                      icon: Image.asset('assets/images/pig.png'),
                      onPressed: () {
                        playSound('sound/pig.wav');
                      },
                    ),
                  ),
                ],
              ),*/
            ],
          ),
        ),
      ),
    );
  }
}
